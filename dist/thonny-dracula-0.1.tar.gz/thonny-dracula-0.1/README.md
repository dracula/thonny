# Dracula for [Thonny](https://github.com/thonny)

> A dark theme for [Thonny](https://github.com/thonny).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/thonny](https://draculatheme.com/thonny).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/thonny/graphs/contributors).

[![Daniel Spinola](https://avatars0.githubusercontent.com/u/51745663?v=3&s=70)](https://github.com/danspinola)
--- | ---
[Daniel Spinola](https://github.com/danspinola)

## License

[MIT License](./LICENSE)